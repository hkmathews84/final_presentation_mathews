# usdata 0.2.0

* Extended county_complete for new ACS 2019 data.
* Added a county_2019 data set for many ACS 2019 variables.

# usdata 0.1.0

* Added a `NEWS.md` file to track changes to the package.
* Added 10 datasets: `county_complete`, `county`, `govrace10`, `houserace10`, `prrace08`, `senaterace10`, `state_stats`, `urban_owner`, `urban_rural_pop`, `vote_nsa`, previously hosted in the openintro package.
* Added 2 functions: `abbr2state`, `state2abbr`, previously hosted in the openintro package.
