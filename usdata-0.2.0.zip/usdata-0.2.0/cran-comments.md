## Resubmission

This is a resubmission that fixes two URL redirects identified in the first submission.

## Test environments

* local OS X install, R 4.1.0
* GitHub Actions (ubuntu-16.04): release
* GitHub Actions (windows): release
* Github Actions (macOS): release, devel
* win-builder: release, devel, oldrelease
* r-hub: windows-x86_64-oldrel, ubuntu-gcc-release, fedora-clang-devel, r-release-linux-x86_64

## R CMD check results

There were no ERRORs or WARNINGs or NOTEs.
