library(testthat)
library(usdata)

test_check("usdata")
